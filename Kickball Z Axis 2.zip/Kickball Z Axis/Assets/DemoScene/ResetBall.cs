﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResetBall : MonoBehaviour
{
	
	public KickBallZ kbZScript;

	void OnMouseDown() {  //  Left-shift click to stop the ball and reset
		if( Input.GetKey( KeyCode.LeftShift ) ) {
			if( kbZScript.rb.isKinematic == true ) { // if ball is already stopped, reset
				kbZScript.ResetBall();
			} else { // stop the ball
				kbZScript.StopBall();
			}
		}
	}


}
