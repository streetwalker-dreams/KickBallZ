﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEditor;

public class testInPass : MonoBehaviour
{
	UnityEngine.Object[] myPrefab;
	public GameObject myPrefabObject;

    // Start is called before the first frame update
    void Start()
    {
		myPrefab = new UnityEngine.Object[1];
		GameObject myObject = Instantiate( myPrefabObject );
		UnityEngine.Object mO = PrefabUtility.GetCorrespondingObjectFromSource( myObject );
		Debug.Log( mO );
	}

    // Update is called once per frame
    void test(float testVal)
    {
		Debug.Log(testVal);
    }
}
