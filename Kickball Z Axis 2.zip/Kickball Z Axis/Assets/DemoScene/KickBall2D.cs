﻿//using UnityEngine;

//public class KickBall2D : MonoBehaviour {
//	public GameObject arrow_assembly; // the arrow assembly object
//	public GameObject scalePivot; // scaling the arrow from the pivot point
//	public LineRenderer screenLine; // for drawing the line in the direction we drag
//	public Camera cam; // a reference to the camera
//	public Material overloadMaterial;
//	public Material loadMaterial;

//	public float maxScale = 5f; // max scale of the arrow
//	public float scaleFactor = 5f;
//	public float kickForce = 1f;
//    //not needed in 2D:
//	//public float maxLoft = 20f;

//	[HideInInspector]
//	public bool ballKicked; // our ResetBall.cs script needs access to this


//	private float forceScale; // will be set by how far we drag
//	private float scaleAmount;
//	private float loftAmount;
//	private float loftAngle;
//	private bool overload = false;
//	private bool oldOverLoad = false;

//	[HideInInspector]
//	public Rigidbody rb; // hook to the physics engine

//	private Plane m_Plane; // we need to create an imaginary plane for the line renderer

//	private void Start() {
//		Physics.bounceThreshold = 0.05f;
//		// hide the arrow
//		arrow_assembly.SetActive( false );
//		scalePivot.transform.localScale = Vector3.zero;
//		// hide our line renderer
//		screenLine.enabled = false;

//		// get the phyics engine of this object (the ball!)
//		//rb = GetComponent<Rigidbody>();

//		//2D:
//		rb = GetComponent<Rigidbody2D>();

//		rb.maxAngularVelocity = 100f;
//		ballKicked = false;

//	}

//	void OnMouseDown() {
//		if( !ballKicked ) {
//			rb.isKinematic = true;
//			// before we show the line render, set endpoints to the same position
//			// so that the line isn't suddenly visible when we enable it
//			//
//			screenLine.SetPosition( 0, transform.position ); // set the fist point of the line
//			screenLine.SetPosition( 1, transform.position ); // set the start position\

//			// move the arrow grandparent to the ball position
//			arrow_assembly.transform.position = transform.position;
//			screenLine.enabled = true;

//			// we want to draw our line on the plane that passes through the cetner of our ball
//			// so a new plane with normal pointing up (0,1,0) at the ball position
//			//
//			//m_Plane = new Plane( Vector3.up, transform.position );
//			//2D:
//			m_Plane = new Plane(Vector3.forward, transform.position);

//			arrow_assembly.SetActive( true ); // show the arrow
//		}
//	}

//	void OnMouseDrag() {
//		// get the mouse position in screen coordinates
//		Vector3 endLoc = Input.mousePosition;

//		//Debug.Log( endDragLoc );

//		//get the end point of the line to draw on the plane the object is on
//		//		Create a ray starting the Mouse drag position
//		//
//		Ray ray = cam.ScreenPointToRay( endLoc );

//		// Initialise the 'enter' variable for ray cast
//		//		we only need to check this variable if we are going to
//		//		let the user point the camera in any arbitrary direction
//		//
//		float cameraDistance = 0.0f;

//		// cast the ray from the end mouse location on the screen to our plane
//		if( m_Plane.Raycast( ray, out cameraDistance ) ) {
//			endLoc = ray.GetPoint( cameraDistance );
//		}
//		// the hitpoint is where our ray intersects the plane we defined
//		screenLine.SetPosition( 1, endLoc );


//		// get the difference between the end drag and start drag vectors
//		//		and calculate the angle they represent with respect to the x axis
//		//
//		Vector3 deltaDrag = endLoc - transform.position; // how far have you dragged in x and y
//		//float angle = Mathf.Atan2( deltaDrag.z, deltaDrag.x ) * Mathf.Rad2Deg; // get a counterclockwise angle
//        //2D:
//		float angle = Mathf.Atan2(deltaDrag.y, deltaDrag.x) * Mathf.Rad2Deg;

//		// Unity rotation performs its rotations clockwise, therefore
//		//		we must negate the angle to convert a clockwise rotation angle
//		// We must also offset the ball and arrow rotation angle because Atan2 uses the x axis as the angle start,
//		//		and Unity uses the z axis and we have oriented our arrow so that it points up on z
//		//		combined with the fact that we want to show the arrow opposite to our line angle
//		//		so we either add 270 or subtract 90
//		// Looking down the y axis, we change only the y axis in the resulting rotations
//		//
//		//arrow_assembly.transform.rotation = Quaternion.Euler( new Vector3( 0, -angle + 270, 0 ) ); // rotate the grandparent
//		//transform.rotation = Quaternion.Euler( new Vector3( 0, -angle + 270, 0 ) );
//		//2D:
//		arrow_assembly.transform.rotation = Quaternion.Euler(new Vector3(0, 0, -angle + 270)); // rotate the grandparent
//		transform.rotation = Quaternion.Euler(new Vector3(0, 0, -angle + 270));

//		//scaleAmout is the raw value to base increase the size of the arrow with the
//		//		drag amout relative to the size of the screen, and to use with kickForce
//		//
//		scaleAmount = deltaDrag.magnitude * scaleFactor;

//		// our scaleAmount affects both the kickForce and the angle we kick into the air
//		//		so we will create assign 'forceScale' only for kicking and scaling the arrow
//		//
//		forceScale = scaleAmount;

//		// we want to make sure we limit the forceScale factor
//		//		and also set overload so we can change the line color
//		if( scaleAmount > maxScale ) {
//			forceScale = maxScale; // limit the scale
//			overload = true;
//		} else {
//			overload = false;
//		}

//		// change the color of the linerenderer only if it changed,
//		//		not every OnMouseDrag iteration
//		//
//		if( overload != oldOverLoad ) {
//			if( overload ) {
//				screenLine.material = overloadMaterial;
//			} else {
//				screenLine.material = loadMaterial;
//			}
//			oldOverLoad = overload;
//		}

//		// if the player drags beyond maxScale, calculate the angle
//		//		to point the ball into the air.
//		//		the first finds the amount we are dragging over maxscale
//		//		and clamps the value between 0 and maxscale * some number
//		//		the second line scales the to an angle between 0 and maxLoft.

//		//loftAmount = Mathf.Clamp( scaleAmount - maxScale, 0f, maxScale * 1.5f );
//		//loftAngle = ( loftAmount / ( maxScale * 1.5f ) ) * maxLoft;

//		//2D: the next 2 lines of code you will not need to shoot a bird, unless
//        //you want to bird to also move upward toward the camera
//		//loftAmount = Mathf.Clamp(scaleAmount - maxScale, maxScale * 1.5f, 0f);
//		//loftAngle = (loftAmount / (maxScale * 1.5f)) * maxLoft;
//		// scale the parent of the arrow graphic - the pivot point
//		//
//		//scalePivot.transform.localScale = new Vector3( forceScale, 0, forceScale );
//		//2D:
//		scalePivot.transform.localScale = new Vector3(forceScale, forceScale, 0);
//	}



//	private void OnMouseUp() {

//		arrow_assembly.SetActive( false ); // hide the arrow
//		scalePivot.transform.localScale = Vector3.zero; // reset the pivot scale
//		screenLine.enabled = false; // hide the line

//		ballKicked = true;
//		rb.isKinematic = false;

//		//if the player drags beyond maxScale, then point the ball into the air
//		//2D, not using for shooting birds
//		//transform.rotation = Quaternion.Euler( loftAngle, transform.eulerAngles.y, transform.eulerAngles.z );

//		//rb.AddForce( transform.forward * forceScale * kickForce, ForceMode.Impulse );
//		//rb.velocity = Vector3.forward * 0.6f; // need to give a little velocity because impulse is not immediate
//		//2D:
//		rb.AddForce( transform.up * forceScale * kickForce, ForceMode.Impulse );
//		rb.velocity = Vector3.up * 0.6f; // need to give a little velocity because impulse is not immediate

//	}

//	private void FixedUpdate() {
//		if( ballKicked ) {
//			if( rb.velocity.magnitude < 0.05f ) {
//				StopBall();
//			}
//		}
//	}

//	public void StopBall() {
//		ballKicked = false;
//		rb.isKinematic = true;
//		rb.velocity = Vector3.zero;
//		rb.angularVelocity = Vector3.zero;
//	}

//	public void ResetBall() {
//        // this function is called by the reset script
//		//transform.position = new Vector3( 0, transform.position.y, 0);
//		//transform.rotation = Quaternion.Euler( 0, 0, 0 );

//        //2D:
//		transform.position = new Vector3(0, 0, transform.position.z);
//		transform.rotation = Quaternion.Euler(0, 0, 0);
//	}
//}
