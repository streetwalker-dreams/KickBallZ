﻿Project Tutorial by Streetwalker Dreams
email:  streetwalker.dreams@gmail.com

Notes:

1. Football model from https://www.turbosquid.com/FullPreview/Index.cfm/ID/460380

  This is a low poly model that imports at a large scale so it needs to be
scaled down to create a regulation 22cm - 23cm diameter football.
The most consistent method is to scale the model down to 0.022 in the import
inspector (click on the prefab in the assests folder) and apply the scaling.

  The model also needs Rigidbody and Collider components if you want to use
Unity's physics engine on it.  Add a Sphere Collider for best results scale the
collider bounds size to match the ball size (you have to eye-ball it).

2. Camera settings

  Set you camera to a vew narrow field (20) of view and position it so your
play area is visibile in the game window.  The narrow field of view minimizes
perspective distortion near the edges of the game window.

3. The Arrow image and material

  Create this in a graphics editor like Photoshp, or import an image from
the Web. In the image import inspector set the Repeat option to 'Clamp'. PNG8 or
PNG24 will produce the clearest image in the materail.
(You do not need the background around the arrow to be transparent for
a sprite shader, but if you don't use a sprite shader in the image import
inspector set the Alpha Source to 'Input Texture Alpha' and turn on the
'Alpha Transparency' option.

  To create the Arrow Material:

A. Create a new material using the Standard Shader
B. Drag the image to the Albedo property of the shader.
C. Finally, change the shader type to Sprites >
Default, and choose the Tint value color to your liking.

If you decide you want to apply a different image, set the shader type back to
the Standard Shader and repeat B, and C.

4. Grass Texture from the Unity Asset Store:
https://assetstore.unity.com/packages/2d/textures-materials/floors/five-seamless-tileable-ground-textures-57060

5. Ball Rigidbody settings and the Kick Ball Z script

A. Make sure you set isSet Collison Detection Mode to Continuous Dynamic if
you set the Kick Force factor to a high number (10 or greater?).  You'll have
to play aound with these settings

B. Don't set isKenimatic on at the beginning in case the ball is slightly off
the ground, we want it to fall to the ground box.

  We use isKenimatic and a boolean variable ballKicked in the script to pull the
ball out of the physics engine if it is not moving fast enough, because there is
no need to make the engine do work.  You can see in the FixedUpdate loop we
check if ballKicked is true. If it is set to false there is no need to check if
it is moving anymore, and therefore less processing to do in the loop. Also, if
you follow the logic in that loop, we would be constantly setting the ball's
isKenimatic and velocity values once the ball has stopped.
